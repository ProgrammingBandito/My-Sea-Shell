My Sea Shell Use Notes:

The makefile is for building an executable from the following files:

-cshellurs.c
-shellfunctions.c
-shellheader.h

To run the shell, go the the folder where the executable 'runthis.out' is located and type: ./runthis.out

Thank you for your time,
DH

