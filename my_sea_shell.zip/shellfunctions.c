/*  Author:             Dominic Hoo
 *  Version:----------> 1.0
 *  Main Shell:         shellfunctions.c
 *  Date:               April 2018
*/

#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <time.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <errno.h>
#include <fcntl.h>
#include "shellheader.h"

#define BUFFSIZE_TOKEN 1024
#define DELIM_TOKEN " \t\n\r\a"


char *input_command (void);
char **discern_command (char *command_line);
int run (char **argv_array);
int ur_cd (char *path);
int redirect (char *file_nom);
void catch_sig (int siggie);
void show_time();

int file_op;
char *file_nom = NULL;
time_t now;
struct tm *whattimeisit;
char size[100];


/*******Signal Handling (for CTRL+C)*******/
void catch_sig (int siggie)
{  
   /* This will clear the text input at current prompt 
    * and replace with a blank prompt upon the user pressing CTRL+C.*/ 
   printf("\n"); 
   printf("[%s]# ", size); 
   fflush (stdout);
    
}

/***Shows Time, Date and Prompt (#)***/
void show_time()
{       
        time (&now);
        whattimeisit = localtime(&now);
        
        strftime (size,100,"%d/%m %H:%M", whattimeisit);
        printf ("[%s]# ",size);   
}

/*Performs output redirection, writes command line operation output to a text file.*/
int redirect (char *file_nom)
{
   /*This will create a file with the user input name.*/
    file_op = open ( file_nom, O_WRONLY | O_CREAT | O_TRUNC , 0666 );
        
   /* This is redirect the output into the user created file by writing the output into the file.
    * It will also close the file operation and 
    * halts the child process from automatically performing future output redirections.
    */
    dup2(file_op, 1);
    close(file_op);
    file_nom = NULL; /*This prevents the child process from redirecting future commands.*/
}

/*custom "cd" implementation*/
int ur_cd (char *path)
{   
    /*The system call, chdir(), changes the directory to desired path.
     *If no argument for cd entered, it will throw default error message.
     */
    if(chdir (path) == -1){perror ("");} 
}

/*Receives user input*/
char *input_command ()
{
    char *command_line = NULL;
    ssize_t buffsize = 0;
    getline(&command_line, &buffsize, stdin);
    
    /*Exits if CTRL+D is entered*/
    if(feof (stdin)){printf ("\n"); exit (EXIT_SUCCESS);} 
    
    return command_line;
    
}

/*  The function below, performs string parsing.
 *  In addition, if the user changes directory (cd) or redirects output (>), 
 *  it will be handled here.
 */
char **discern_command (char *command_line)
{
    int buffsize = BUFFSIZE_TOKEN, pos = 0;
    char **tokens = malloc(buffsize * sizeof(char*)); 
    char *token;
    
    /*String parsing occurs here*/
    token = strtok (command_line, DELIM_TOKEN);
    
    while (token != NULL) 
    {
            
        if (!strcmp (token, "cd"))
        {   
           /*Changes Directory upon user input of "cd"
            *through the function "ur_cd (token)".
            */
            token = strtok (NULL, DELIM_TOKEN);
            ur_cd (token);
        }
        else if (!strcmp (token, ">"))
        {   
            /* This will detect ">" to begin output redirection, 
             * token stores the filename.
             */
            file_nom = strtok (NULL,DELIM_TOKEN);
        }
        else
        {   
            /*This returns the user input that are not "cd" or ">" for 
             *normal operation in the "run" function.
             */
            tokens[pos] = token; 
            pos++;
            
            if (pos >= buffsize)
            {   
                /*If user enters too many arguments, the tokenization will not occur. 
                 *This is hard to perform as limit is large.
                 */
                fprintf (stderr, "ERROR: Too many arguments, try less please.\n");
                tokens[0] = NULL;
                return tokens;
            }
        }
        
        /*Parses through the next word of the same string.*/   
        token = strtok (NULL, DELIM_TOKEN);  
    }
    
    /*Assigning NULL at end of the list.*/
    tokens[pos] = NULL; 
    return tokens;
}

int run (char **argv_array)
{
    /* Executes command from user input. 
     * Parent process spawns a Child process 
     * through fork() and exec().
     */
    pid_t pid;
    int stat;
    int exec_check;
    
    /** fork() creates Child process. **/
    pid = fork();
    
    /** When fork is successful the  commands will be executed. **/
    if (pid == 0){
        
        /* Output Redirect occurs below. 
         * This will only occur if user has entered ">" previously.
         */
        if ( file_nom != NULL )
        {   
            redirect (file_nom);
        }
        
        /*Passes user commands into the execvp system call for actual operation of desired command 
         * i.e. will carry out "ls", "pwd", "sleep" etc. 
         * In addition standard errors will occur if user tries to access restricted directories or files.
        */
        exec_check = execvp (argv_array[0],argv_array); 
        
        /*If command entered is non-existant or non-sensical, this error will be activated and user prompt resets.*/
        if (  exec_check == -1 ){ perror ("ERROR ==> Cannot execute!!"); }
        
        /*Closes Child process.*/
        exit (EXIT_FAILURE);
        
    }
    else if (pid < 0){ /*If fork fails*/ perror("PID invalid!!");}
    else
    {
        /*Parent is waiting for child process to complete.*/
        wait (&stat);
        file_nom = NULL;
    }
    
    /*In the main loop (cshellurs.c), keeps the loop repeating.*/
    return 1;
        
}
    
