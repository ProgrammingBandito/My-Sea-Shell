/*  Author:             Dominic Hoo, 
 *  Version:----------> 1.0
 *  Main shell:       	cshellurs.c
 *  Date: 		April 2018
*/

#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include <stdio.h>
#include <string.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <time.h>
#include <errno.h>
#include <signal.h>
#include "shellheader.h"

#define BUFFSIZE_TOKEN 1024
#define DELIM_TOKEN " \t\n\r\a"

int shtop;
char *input_command (void);
char **discern_command (char* command); 
int run (char **argv_array);

/***********Functions*********************/
void catch_sig (int siggie);
void show_time();
/*****************************************/

/* The "main" loop will enter an infinite do_while loop. 
 * Which will call on functions from "shellfunctions.c" to run 'Sea' shell.
 */

int main (int argc, char **argv)
{   
    char *command;
    char **argv_array;
      
    do{
        
        /****SIGNAL HANDLING***/
        signal (SIGINT, catch_sig);

        /****Time Display (with Prompt, #)******/
	show_time();
	
        /**Performs the core functions of the program:
        1. Receives user input.
        2. Parses through the user input string.
        3. Executes the command based on the string parsed by "discern_command" function.
         **/
        command = input_command ();
        argv_array = discern_command (command);
        shtop = run (argv_array);
        
        }while(shtop);
    
    return EXIT_SUCCESS;
}
