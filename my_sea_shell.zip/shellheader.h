/* Author:		Dominic Hoo 
 * Version:------------> 1.0                
 * Main Shell: 		shellheader.h 
*/

void catch_sig (int siggie);

void show_time();

char *input_command(void);

char **discern_command(char *command_line);

int run(char **argv_array);
